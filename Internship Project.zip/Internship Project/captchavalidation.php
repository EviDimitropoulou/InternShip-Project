<?php
if (isset($_POST['submit']) == "Enter")
		    session_start();
			echo "correct !";
        $cap = $_POST['captcha'];
       if ($cap == $_SESSION['digit']) {
		   echo "correct";
		   $password = mysqli_real_escape_string($conn, $_POST['password']);
			
		   $hash2 = "SELECT hashedpw from register_user where email='$email' ";
		$result_hash2 = mysqli_query($conn, $hash) or die(myslqi_error($conn));

    //elegxw an o hashed(tis basis) tairiazei me ton kwdiko pou eisagei o xrhsths
    if (mysqli_num_rows($result_hash2) >= 0) {
        while ($row = mysqli_fetch_assoc($result_hash2)) {
            $pas_res = password_verify($password, $row["hashedpw"]);
        }
		echo"dsdas";
		} 
	 }else{
		  die("Sorry, the CAPTCHA code entered was incorrect!");   
	   }
	 ?>