﻿<!DOCTYPE html>

<html >
    <head>
        <title>Login</title>
        <meta charset="utf-8">
        <!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
        To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
        <script src="jquery-1.12.4.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
        <script src="http://1000hz.github.io/bootstrap-validator/dist/validator.min.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="script.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
        <link type="javascript" href="js/bootstrap.js" />
        <link type="javascript" href="js/bootstrap.min.js" />	
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>

    <body>

        <div class="container">
            <div  class="row">
                <h3> Login to Account</h3>
                <div class="col-md-6"> 

                    <form data-toggle="validator" role="form" name="login-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <!--edw nomizw tha pigenei sthn selida toy xrhsth efoson  einai eggegrammenos uparxei-->

                        <!--pedio pou simplirwnei o xrhstis to email tou-->
                        <div class="form-group login_form ">
                            <input type="text" name= "email" class="form-control" id="inputEmail" placeholder="Enter Your Email"  required>
                        </div>
                        <!--pedio pou simplirwnei o xrhstis to kwdiko tou-->
                        <div class="form-group  login_form">
                            <input type="password" name="password" class="form-control" id="password" placeholder="Enter password" required>
                        </div>	
                </div>
            </div>		
            <!--koumpaki gia to submit ths formas-->
            <div class="form-group col-md-6">
                <input id="submit"  name= "submit" value="Log In" class="btn btn-default" type="Submit"/>

            </div>
        </form>

    </div>
    <div class="container">
        <!-- klisi kwdika gia thn apostoli mail an ksexase ton kwdiko tou-->
        <a href="entermail.php "> forgot password</a>
    </div>
    <script language="JavaScript">
// Code for validating the form
// Visit http://www.javascript-coder.com/html-form/javascript-form-validation.phtml
// for details
        var frmvalidator = new Validator("login-form");
//remove the following two lines if you like error message box popups
        frmvalidator.EnableOnPageErrorDisplaySingleBox();
        frmvalidator.EnableMsgsTogether();

//frmvalidator.addValidation("name","req","Please provide your name"); 
//frmvalidator.addValidation("email","req","Please provide your email"); 
//frmvalidator.addValidation("email","email","Please enter a valid email address"); 
    </script>
    <script language='JavaScript' type='text/javascript'>
        function refreshCaptcha()
        {
            var img = document.images['captchaimg'];
            img.src = img.src.substring(0, img.src.lastIndexOf("?")) + "?rand=" + Math.random() * 1000;
        }
    </script>
</body>

</html>

<?php

include("connect.php");
session_start();
date_default_timezone_set('Europe/Athens');
$script_tz = date_default_timezone_get();
if (isset($_POST['submit']) == "Log In") {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
 
 //$email1=_SESSION['email'];
    // Get the IP address of the visitor 
    $ip = $_SERVER['REMOTE_ADDR']; // apothikeuoume thn ip se mia metabliti
    $_SESSION['ip'] = $ip;

    $hash = "SELECT hashedpw from register_user where email='$email' ";
    $result_hash = mysqli_query($conn, $hash) or die(myslqi_error($conn));

    //elegxw an o hashed(tis basis) tairiazei me ton kwdiko pou eisagei o xrhsths
    if (mysqli_num_rows($result_hash) >= 0) {
        while ($row = mysqli_fetch_assoc($result_hash)) {
            $pas_res = password_verify($password, $row["hashedpw"]);
        }
    }
    //epilogi tou mail 
    $sql1 = "SELECT email FROM register_user where email='$email'";
    $result3 = mysqli_query($conn, $sql1) or die(myslqi_error($conn));
    $count_mail = mysqli_num_rows($result3);

    //swsth authedikopoihsh xrhsth
    if (($count_mail <> 0)&&($pas_res)) {
        $query = $conn->prepare("INSERT INTO login_attempts (IP,loginTime,successLogin,email)VALUES (?,?,?,?)");
        $query->bind_param('ssis', $ip, $loginTime, $successLogin, $email);
        $successLogin = 1;
        $query->execute();
	//paragwgi link me credentials tou User
		$name="SELECT name  as name from register_user where email='$email'";
		$result_name=mysqli_query($conn,$name)or die(mysqli_error($conn));
		$r=mysqli_fetch_assoc($result_name);
		
		$id="SELECT id as id from register_user where email='$email'";
		$result_id=mysqli_query($conn,$id)or die(mysqli_error($conn));
		$i=mysqli_fetch_assoc($result_id);
     
        ?>
		<script>
            window.location.href = 'UserContent.php?name=<?php echo $r['name']?>&id=<?php echo $i['id']?>';
        </script>
        <?php 
    }

    //eisagwgh lathous mail, diladi den iparxei kapoio mail kataxwrimeno 
    elseif ($count_mail == 0) {


        //prosthiki prospatheiwn ston pinaka login Attempts
        $query = $conn->prepare("INSERT INTO login_attempts (IP,loginTime,successLogin,email)VALUES (?,?,?,?)");
        $query->bind_param('ssis', $ip, $loginTime, $successLogin, $email);
        $successLogin = 0; //fail login
        $query->execute();

        //eisagwgi ston pinaka blockedIP tis apotiximenes prospatheies (panw apo 2) sto diastima twn 5 leptwn
        $st2 = "INSERT INTO `blockedIP` (IP,loginTime,failures) SELECT IP, loginTime,successLogin from login_attempts where successLogin=0 AND (loginTime > CURRENT_TIMESTAMP-INTERVAL 15 MINUTE ) having count(successLogin)>=2 AND IP='" . $_SERVER['REMOTE_ADDR'] . "' ";
        // That inserts the data from login  to blockedIP
        $res2 = mysqli_query($conn, $st2);

        $st3 = "SELECT count(failures) as fail from `blockedIP` where IP='" . $_SERVER['REMOTE_ADDR'] . "'";
        $res = mysqli_query($conn, $st3); //thetw to aitima 
        $row_cnt =mysqli_fetch_assoc($res);	//metraw tis eggrafes pou iparxoun 
		echo $row_cnt['fail'];
			//login throttling: that is, setting a time delay between attempts after N failed attempts (yes, DoS attacks are still possible, but at least they are far less likely and a lot more complicated to pull off
			
			if($row_cnt['fail']>=3){
				sleep(30);//30 seconds
				echo"Loading..........";
				
			}elseif($row_cnt['fail']>=6){
				sleep(900);//15minutes
				echo"Loading..........";
			}
	
					}
    elseif (!$pas_res) {
		   ?>
       <!--elegxos captcha an einai swsto feugei query alliws den stelnw aitima sthn basi gia epanelegxo kwdikou -->
		<form method="post" name="contact_form" action="captchavalidation.php">
		 <div class = "container">
		 <h5>please enter your password again</h5>
            <p><img src="captcha.php?rand=<?php echo rand(); ?>" width="150" height="40"id="captchaimg"  border="2" alt="CAPTCHA"></p>
            <p><input type="text" size="6" maxlength="5" name="captcha" ><br>
                <small>copy the digits from the image into this box</small></p>	
            <small>Cant read the image? click <a href="javascript: refreshCaptcha();">here</a> to refresh</small>

            <input type="submit" id="submit"value="Enter" name="submit">
			</form>
        </div>
     <?php
     
    }
}

?>

