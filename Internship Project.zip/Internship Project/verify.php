
<!-- forma gia thn simplirwsi tou mail-->
<!DOCTYPE html>
<html >
    <head>
        <meta charset="utf-8" />
        <title>Verify Account</title>
        <meta charset="utf-8">
        <!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
        To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
        <script src="jquery-1.12.4.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
        <script src="http://1000hz.github.io/bootstrap-validator/dist/validator.min.js"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://github.com/PHPMailer/PHPMailer.git"></script>
        <script src="script.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
        <link type="javascript" href="js/bootstrap.js" />
        <link type="javascript" href="js/bootstrap.min.js" />	
        <link rel="stylesheet" type="text/css" href="style.css" />

    </head>

    <body>
 <div class="header">
            <br>
            <a href="loginform.php"><button type="submit" class="button button-small primary" style="margin-left:1000px;" name="Login" value="Login">Login</button></a>
        </div>

        <div class="container">
            <div  class="row">
                <h3> Verify Account</h3>
                <div class="col-md-6"> 
                    <!-- to data toggle anaferetai sthn bibliothiki pou xrisimopoioume gia na ginei to validate ths formas-->
                    <form data-toggle="validator" role="form" method="POST" action="verify.php">
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" id="inputEmail" placeholder="Email" data-error="That email address is invalid" required>
                            <div class="help-block with-errors"></div>
                            <div class="form-group col-md-6">
                                <input type="text"  name="verifyID"class="form-control" title="Please enter the code we sent you" id="verifyID" placeholder="Verification Code" required>
                            </div>
                        </div>

                        <div class="form-group col-md-6">
                            <input id="submit" class="btn btn-default" name="submit" value ="Send" type="submit">
                        </div>

                </div>

            </div>
        </div>
    </div>
</body>
 
</html>
<?php
include "connect.php";
if (isset($_POST['submit']) == "Send") {
    echo "ds";
    $email = mysqli_real_escape_string($conn, $_POST['email']);
	$verifyID = mysqli_real_escape_string($conn, $_POST['verifyID']);
	

	   $select_user = "SELECT email FROM register_user where email='$email'  and verify_ID='$verifyID' ";
    $result_user = mysqli_query($conn, $select_user) or die(myslqi_error($conn));
    $count_user = mysqli_num_rows($result_user);

    if ($count_user ==1) {
        $query = $conn->prepare("UPDATE `register_user` SET `verified`=? WHERE `email`=? and `verify_ID`=?");
        $query->bind_param('sss', $verified, $email, $verifyID);
		
        $verified = 'T';
		$email = mysqli_real_escape_string($conn, $_POST['email']);
		$verifyID = mysqli_real_escape_string($conn, $_POST['verifyID']);
		
        $query->execute();
        echo "Congrats! You are verified!";
   } else {
       
       exit();
   }
}
?>