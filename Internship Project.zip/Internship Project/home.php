
<!DOCTYPE html>

<html >
<head>
    <meta charset="utf-8" />
    <title>Home Page</title>
	<meta charset="utf-8">
	<!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
	To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
	<link type="javascript" href="js/bootstrap.js" />
	<link type="javascript" href="js/bootstrap.min.js" />	
	<link rel="stylesheet" type="text/css" href="style.css" />
	<style>
	a:link, a:visited {
    background-color: #f44336;
    color: white;
    padding: 14px 25px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}


a:hover, a:active {
    background-color: red;
}
</style>
</head>
</head>
<body>
<div class="container">
<h3>Welcome</h3>
<div class "row">

<div class="col-sm-6"> 

<form method ="post"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
<a href="RegisterForm.php">Register</a>

<a href="loginform.php">Login </a>
</form>

</div>
</div>
</div>
</body>

</html>
<?php

session_start();

$db_host= "localhost";
$username = "edimitrop";
$password="PD435@yo%Ad2";
$dbname= "slmc_interns";

//create connection
$conn =new mysqli($db_host,$username,$password,$dbname);

//check connection
if(!$conn){
	die("Connection failed:". mysqli_connect_error());
	
}

?>