
<!DOCTYPE html>

<html >
    <head>
        <meta charset="utf-8" />
        <title>User</title>
        <meta charset="utf-8">
        <!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
        To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
        <link type="javascript" href="js/bootstrap.js" />
        <link type="javascript" href="js/bootstrap.min.js" />	
        <link rel="stylesheet" type="text/css" href="style.css" />
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>


    <body>

        <div class="container">
            <h3>Welcome to your Profile!</h3>
            <div class "row">
                 <div class="col-ms-4">


                    <ul class="nav nav-tabs nav-justified">
                        <li class="active"<a data-toggle="tab" href="#home">Home</a></li>
                        <li><a data-toggle="tab" href="#menu1">Information</a></li>
                        <!--<li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
                        <li><a data-toggle="tab" href="#menu3">Menu 3</a></li>-->
                    </ul>
                    <div class="tab-content">
                        <div id="home" class="tab-pane fade in active">
                     
                            <p>
                            <form id ="uploadfile" action="upload.php" method="post" enctype="multipart/form-data">
                                Select File to upload:
                                <input 	type="file" name="file" id="file" />
                               <span> <input id="submit" class="btn btn-default" name="submit" value ="Upload"type="submit"></span>
                            </form>
                            </p>
                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <h3>Info</h3>
                            <form action="personalinfo.php" method="Post" name="personalinfo"    >
                                <fieldset>
                                    <legend>Personal information:</legend>
                                    First name:<br>
                                    <input type="text" name="firstname" value=""><br>
                                    Last name:<br>
                                    <input type="text" name="lastname" value=""><br>
                                    Education:<br>
                                    <input type="text" name="education" value=""><br>
                                    About me:<br>
                                    <textarea rows = "4" name="textarea" maxlength="100" placeholder = "Kείμενο μέχρι 100 λέξεις"></textarea>

                                    <input type="submit" value="Submit" name="submit">
                                </fieldset>
                            </form></p>
                            <?php
                            if (isset($_POST['submit']) == "Submit") {
                                echo "dsd";
                                $stmt = $conn->prepare("INSERT INTO userinfo VALUES (firstname,lastname,education,aboutme)VALUES(?,?,?,?)");

                                $stmt->bind_param('ssss', $name, $surname, $education, $textarea);

                                $name = mysqli_real_escape_string($conn, $_POST['name']);
                                $surname = mysqli_real_escape_string($conn, $_POST['lastname']);
                                $education = mysqli_real_escape_string($conn, $_POST['education']);
                                $aboutme = mysqli_real_escape_string($conn, $_POST['textarea']);
                                $stmt->execute();
                            }
                            ?>
                        </div>
                        <!--<div id="menu2" class="tab-pane fade">
                            <h3>Menu 2</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                        </div>
                        <div id="menu3" class="tab-pane fade">
                            <h3>Menu 3</h3>
                            <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                        </div>
                    </div>-->
                    
                    
                </div>

            </div>
        </div>
    </body>
    <?php
    session_start();
    include("connect.php");
    
    ?>

</html>