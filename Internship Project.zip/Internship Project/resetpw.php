<!-- forma gia thn simplirwsi tou mail-->
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8" />
    <title>Reset password</title>
	<meta charset="utf-8">
	<!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
	To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
	<script src="jquery-1.12.4.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	<script src="http://1000hz.github.io/bootstrap-validator/dist/validator.min.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://github.com/PHPMailer/PHPMailer.git"> </script>
	<script src="script.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
	<link type="javascript" href="js/bootstrap.js" />
	<link type="javascript" href="js/bootstrap.min.js" />	
	<link rel="stylesheet" type="text/css" href="style.css" />
	
</head>

<body>
		
		
		<div class="container">
		<div  class="row">
		<h3> Reset your password</h3>
		<div class="col-md-6"> 
		<!-- to data toggle anaferetai sthn bibliothiki pou xrisimopoioume gia na ginei to validate ths formas-->
		<form data-toggle="validator" role="form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
	
		   <div class="form-group">
		   <input type="email" class="form-control" name="email" id="inputEmail" placeholder="Email" data-error="That email address is invalid" required>
				<div class="help-block with-errors"></div>
                                <div class="form-group col-md-6">
								<!-- password regex was data-minlength="6" name="password"class="form-control" pattern= ".+[a-zA-Z0-9]{1,}.*[&@\#$%*()_+!]" size="12" 
								new constract defined here http://stackoverflow.com/questions/3802192/regexp-java-for-password-validation duplicate from registration page -->
                                    <input type="password" name="password"class="form-control" pattern= "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\S+$).{6,12}$" title="Please define your desired password" id="inputPassword" placeholder="Password" required>

                                </div>
                                <!-- This here is the password field  confirmation-->
                                <div class="form-group col-md-6">
                                    <input type="password" class="form-control" name="passwordConfirm" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match" placeholder="Confirm" required>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="help-block"><i>Password must contain 6-12 characters. Including at least one uppercase one lowercase letter and one number.No blanks are permitted</i></div>

                            </div>
		<div class="form-group col-md-6">
		<input id="submit" class="btn btn-default" name="submit" value ="Reset" type="Submit">
		</div>
		</div>
		</div>
		</div>
		</body>

		</html>
		
<?php
session_start();
//require_once "vendor/autoload.php";


include "connect.php";
include "class.phpmailer.php";

if (isset($_POST['submit']) == "Reset") {
 
 
	$query = $conn->prepare("UPDATE `register_user` SET `hashedpw`=? WHERE `email`=?");
    $query->bind_param('ss',  $hash,$email);

    $passwordfromPost = mysqli_real_escape_string($conn, $_POST['password']);
    $passwordConfirm = mysqli_real_escape_string($conn, $_POST['passwordConfirm']);
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	$_SESSION['email']= $email;
	// $hash password;
    $options = ['cost' => 12,];
    $hash = password_hash("$passwordfromPost", PASSWORD_BCRYPT, $options);

	$query->execute();
		if($query){
		
		send_mail($email,$passwordfromPost);
	}else{
		echo " cant do this ";
	}
	
	
}


function send_mail($email,$passwordfromPost){
	
$mail = new PHPMailer();
$mail->isSendmail();

$mail->CharSet = "text/html; charset=UTF-8;";
//Set who the message is to be sent from
$mail->setFrom('NoReply@careers.strategylens.gr', 'StrategyLens');

//Set an alternative reply-to address
$mail->addReplyTo('NoReply@careers.strategylens.gr', 'StrategyLens');

//Set who the message is to be sent to
$mail->addAddress($email, $email);
$message= " Your Password  has changed! your password is: $passwordfromPost ";
$mail->IsHTML($message);
$mail->Body =$message;
$mail->AltBody =$message;
//Set the subject line
$mail->Subject = 'PHPMailer mail() test';
	if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}
}

?>
