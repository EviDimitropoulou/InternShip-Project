
<!-- forma gia thn simplirwsi tou mail-->
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8" />
    <title>Login</title>
	<meta charset="utf-8">
	<!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
	To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
	<script src="jquery-1.12.4.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	<script src="http://1000hz.github.io/bootstrap-validator/dist/validator.min.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="https://github.com/PHPMailer/PHPMailer.git"> </script>
	<script src="script.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
	<link type="javascript" href="js/bootstrap.js" />
	<link type="javascript" href="js/bootstrap.min.js" />	
	<link rel="stylesheet" type="text/css" href="style.css" />
	
</head>

<body>
		
		
		<div class="container">
		<div  class="row">
		<h3> Forgot password</h3>
		<div class="col-md-6"> 
		<!-- to data toggle anaferetai sthn bibliothiki pou xrisimopoioume gia na ginei to validate ths formas-->
		<form data-toggle="validator" role="form" method="POST" action="entermail.php">
		
				<div class="form-group ">
				<input type="email" class="form-control" name="email" id="inputEmail" placeholder="Email" data-error="That email address is invalid" required>
				<div class="help-block with-errors"></div>
				<input type="email" class="form-control" name="emaill" id="inputEmail1" placeholder=" Enter Again Your Email" data-error="That email address is invalid" required>
				<div class="help-block with-errors"></div>
				</div>
		<div class="form-group col-md-6">
		<input id="submit" class="btn btn-default" name="submit" value ="Send" type="Submit">
		</div>
		</div>
		</div>
		</div>
		</body>

		</html>
		
<?php


include "connect.php";
include "class.phpmailer.php";

if (isset($_POST['submit'])== "Send") {
 
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $emaill = mysqli_real_escape_string($conn, $_POST['emaill']);
	


	//elegxos gia thn uparxh tou email sthn basi me tous registered users
    $sql1 = "SELECT email FROM register_user where email='$email'";
    $result3 = mysqli_query($conn, $sql1) or die(myslqi_error($conn));
    $count_mail = mysqli_num_rows($result3);
   	if($count_mail==0){
		//to email den uparxei 
		echo'<b>Your account doesnt exist, please <a href="RegisterForm.php"> register! </a></b>';
	}else{
		//to email uparxei kai tha stalthei mail
		echo"<b>we will send you email for reset your password!<b>";
		
		send_mail($email);
	}
	
}
function send_mail($email){
	session_start();
$mail = new PHPMailer();
$mail->isSendmail();

$mail->CharSet = "text/html; charset=UTF-8;";
//Set who the message is to be sent from
$mail->setFrom('NoReply@careers.strategylens.gr', 'StrategyLens');
//Set an alternative reply-to address
$mail->addReplyTo('NoReply@careers.strategylens.gr', 'StrategyLens');

//Set who the message is to be sent to
$mail->addAddress($email, 'Evi Dimitropoulou');
$message= "Follow the link for reset your password<html><body><a href='http://192.168.75.243/slinterns/evi_dimitropoulou/resetpw.php'> Reset Password</a> </body></html> ";
$mail->IsHTML($message);
$mail->Body =$message;
$mail->AltBody =$message;
//Set the subject line
$mail->Subject = 'PHPMailer mail() test';
	if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}
}

?>
