<?php
session_start();
if (isset($_POST['submit']) == "Upload") {
//The global $_FILES will contain all the uploaded file information. 
        //The original name of the file on the client machine.
        $file = mysql_real_escape_string($_FILES['file']['name']);
        $file_loc = mysql_real_escape_string($_FILES['file']['tmp_name']);
        $file_size = mysql_real_escape_string($_FILES['file']['size']);
        $file_type =mysql_real_escape_string( $_FILES['file']['type']);
		$email= $_SESSION['email'];
        echo $file;
        echo $file_size;
        echo $file_type;
        $ok = 1;
        $uploaddir = "uploads/";
        $uploadfile = $uploaddir . basename($_FILES['file']['name']);
        if ($file_size > 350000) {
            echo "Your file is too large.<br>";
            $ok = 0;
        }

        $fp = fopen($file_loc, 'r');
        $content = fread($fp, filesize($file_loc));
//$content=addslashes($content);


        if ($ok == 0) {
            echo "Possible file upload attack!\n";
        } else {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
                echo "\n. file " . basename($_FILES['file']['name']) . "File is valid, and was successfully uploaded.\n";
            } else {
                echo "Sorry, there was a problem uploading your file.";
            }

            $sql = ("INSERT INTO uploadfile(file,type,size,UserEmail) VALUES('$file','$file_type','$file_size','$email')");
            mysqli_query($conn,$slq);
		

            if ($sql) {
                echo "insert";
            } else {
                echo "no";
            }
        }	
    }?>