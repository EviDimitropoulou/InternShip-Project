<!--eisodos tou query me prepared statements -->
<!DOCTYPE>
<?php
session_start();
include "connect.php";
include "class.phpmailer.php";

date_default_timezone_set('Europe/Athens');
$script_tz = date_default_timezone_get();

//define the variables
$fname = "";
$lname = "";
global $email ;
$passwordfromPost = "";
$passwordConfirm = "";
$phone = "";
$birthdate = "";
$emailEr = "";

function randomNumber($length) {
    $result = '';

    for($i = 0; $i < $length; $i++) {
        $result .= mt_rand(0, 9);
    }

    return $result;
}


if (isset($_POST['submit']) == "Submit") {
	//exactly one mail
	     $email = mysqli_real_escape_string($conn, $_POST['email']);
			
		
    //insert into database
    $query = $conn->prepare("INSERT INTO register_user (name,surname,email,phone,hashedpw,birthdate,date_registered,verified,verify_ID)VALUES (?,?,?,?,?,?,?,?,?)");
    $query->bind_param('sssssssss', $fname, $lname, $email, $phone, $hash, $birthdate, $timestamp,$verified,$verify_ID);
	
	
	
    $fname = mysqli_real_escape_string($conn, $_POST['name']);
    $lname =mysqli_real_escape_string($conn, $_POST['surname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $passwordfromPost = mysqli_real_escape_string($conn, $_POST['password']);
    $passwordConfirm = mysqli_real_escape_string($conn, $_POST['passwordConfirm']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['date']);
    $timestamp = date('Y-m-d G:i:s');
	$verified='F';
	
	$verify_ID=  randomNumber(12) ;
	$_SESSION['verify_ID']=$verify_ID;
    // hash password
    $options = ['cost' => 12,];
    $hash = password_hash("$passwordfromPost", PASSWORD_BCRYPT, $options);
	$select ="SELECT email from register_user where email='$email' ";
			$result_select = mysqli_query($conn, $select) ;
			$count=mysqli_num_rows($result_select);
			echo $count;
			if($count>=1){
			echo"sim";
		    exit("This email is already being used");
		}
	$query->execute();
		
	if($query){
		send_mail($email,$verify_ID,$name);
		echo $count;
	}else{
		echo " cant do this ";
	}
	//send_mail();

  
}



function send_mail($email,$verify_ID,$name){


$mail = new PHPMailer();
$mail->isSendmail();

$mail->CharSet = "text/html; charset=UTF-8;";
//Set who the message is to be sent from
$mail->setFrom('@careers..gr', 'StyLns');

//Set an alternative reply-to address
$mail->addReplyTo('Noly@careers.ss.gr', 'StyLns');

//Set who the message is to be sent to
$mail->addAddress($email,$name) ;  

$message=" Please follow the link and enter the code below!  Link:  http://192/slinterns/evi_dimitropoulou/verify.php
 Password:  $verify_ID";
$mail->IsHTML($message);
$mail->Body = $message;

$mail->AltBody =$message;

//Set the subject line
$mail->Subject = 'PHPMailer mail() test';
	if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";

}
}

?>

<html >
    <head>
        <meta charset="utf-8" />
        <title>Register</title>
        <meta charset="utf-8" charset="iso8859-7"/>
        <!--Bootstrap 3 is designed to be responsive to mobile devices. Mobile-first styles are part of the core framework.
        To ensure proper rendering and touch zooming, add the following <meta> tag inside the <head> element:-->
        <script src="jquery-1.12.4.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
        <script src="http://1000hz.github.io/bootstrap-validator/dist/validator.min.js"></script>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css" />
        <link type="javascript" href="js/bootstrap.js" />
        <link type="javascript" href="js/bootstrap.min.js" />	
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>

    <body>
        <div class="header">
            <br>
            <a href="loginform.php"><button type="submit" class="button button-small primary" style="margin-left:1000px;" name="Login" value="Login">Login</button></a>
        </div>

        <div class="container">
            <div  class="row">

                <div class="col-md-6"> 
                    <form data-toggle="validator" method="post" role="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <h3> Please Register</h3>
                        <div class="signup_form" >
                            <div class="form-group ">
                                <!-- This here is the Name Field-->
                                <input type="text" class="form-control" name="name" id="inputName" placeholder="Enter Name" required>
                            </div>
                            <!-- This here is the Surname Field-->
                            <div class="form-group ">
                                <input type="text" class="form-control" name="surname" id="inputsurName" placeholder="Enter surname" required>
                            </div>
                            <!-- This here is the Email field -->
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" id="inputEmail" placeholder="Email" data-error="That email address is invalid" required>
                                <div class="help-block with-errors"></div>
                            </div>
                            <!-- This here is the password field  validation through regex-->
                            <div class="form-group">
                                <div class="form-group col-md-6"> <!--was ".+[a-zA-Z0-9]{1,}.*[&@\#$%*()_+!]" data-minlength="6" maxlength="12" 
								new construct defined here http://stackoverflow.com/questions/3802192/regexp-java-for-password-validation ^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\\S+$).{6,12}$
								^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,}$-->
                                    <input type="password" name="password"class="form-control" pattern= "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=\S+$).{6,12}$" title="Please define your desired password" id="inputPassword" placeholder="Password" required>

                                </div>
                                <!-- This here is the password field  confirmation-->
                                <div class="form-group col-md-6">
                                    <input type="password" class="form-control" name="passwordConfirm" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match" placeholder="Confirm" required>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="help-block"><i>Password must contain 6-12 characters. Including at least one uppercase one lowercase letter and one number.No blanks are permitted</i></div>

                            </div>
                            <!-- This is the Phone field Validation-->
                            <div class="form-group">
                                <input type="phone" class="form-control" name="phone" maxlength="14" pattern= "^[\+|30]\d{7,}[^\s]$"  title="format:(+30**********) or(+***********)" size="14" id="inputPhone" placeholder="Enter phone (+***********) " required>
                            </div><!--[\+](?=.*\d){14}-->
                            <div class="form-group">
                                <!-- This here is the Date of Birth field -->

                                <input type="datetime" class="form-control" pattern="[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01][^\s]$)" name="date" title="Format :(yyyy-mm-dd)" id="inputDate" placeholder="Enter your BirthDate: yyyy-mm-dd " required>
                            </div>
                        </div>
                </div>
            </div>
            <div class="form-group col-md-6">
                <input id="submit" class="btn btn-default" name="submit" value ="Submit"type="submit">
            </div>
        </form>
    </div>

</body>

</html>

