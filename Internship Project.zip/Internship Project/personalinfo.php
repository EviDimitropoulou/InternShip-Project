<?php
include "connect.php";
session_start();
if(isset($_POST['submit']) == "Submit"){
	
	echo "dsd";
	$stmt=$conn->prepare("INSERT INTO userinfo  (firstname,lastname,education,aboutme,email)VALUES(?,?,?,?,?)");
	
	$name=mysqli_real_escape_string($conn, $_POST['firstname']);
	$surname=mysqli_real_escape_string($conn, $_POST['lastname']);
	$education=mysqli_real_escape_string($conn, $_POST['education']);
	$aboutme=mysqli_real_escape_string($conn, $_POST['textarea']);
	
	$email= $_SESSION['email'];
	$stmt->bind_param('sssss',$name,$surname,$education,$aboutme,$email);
	
	
	
	$stmt->execute();
	
	
	
}


?>
